clear; clc; close all

L_TOTAL   = 1.19;             
BIN_COUNT = 250;              
BIN_SIZE  = L_TOTAL / BIN_COUNT;
N_ELE     = BIN_COUNT;
N_NODE    = N_ELE + 1;
NDPN      = 4;               
N_DOFG    = N_NODE * NDPN;
N_FREE    = N_DOFG - 8;       
MID_NODE  = floor((N_NODE-1)/2);
L_NODE =floor((N_NODE-1)/4);

E_MOD     = 107e9;            
RHO_STL   = 8400;            
D_INNER   = 0;          
D_OUTER   = 0.0127;          
Iy        = pi*(D_OUTER^4 - D_INNER^4)/64;
Iz        = Iy;
A         = pi*(D_OUTER^2 - D_INNER^2)/4;

RHO_FLUID = 1000;             
A_DISP    = pi*(D_OUTER/2)^2; 


GAMMA_NM = 0.5;
BETA_NM  = 0.25;


dof2free = -ones(N_DOFG,1);   
free_dof = zeros(N_FREE,1);
k = 1;
for n = 1:N_NODE
    for loc = 0:NDPN-1
        glob = (n-1)*NDPN + loc + 1;
        if n==1 || n==N_NODE
            dof2free(glob) = -1;
        else
            dof2free(glob) = k-1;
            free_dof(k)    = glob;
            k = k+1;
        end
    end
end

Kf        = zeros(N_FREE, N_FREE);
Mf_struct = zeros(N_FREE, N_FREE);
Mf_add    = zeros(N_FREE, N_FREE);

for e = 1:N_ELE
    Le = BIN_SIZE;
    
    kv = [12     6*Le  -12    6*Le;
          6*Le   4*Le^2 -6*Le 2*Le^2;
         -12    -6*Le   12    -6*Le;
          6*Le   2*Le^2 -6*Le 4*Le^2];
    kw = kv;
    vidx = [1 4 5 8];
    widx = [2 3 6 7];
    Ke   = zeros(8,8);
    for i = 1:4
        for j = 1:4
            Ke(vidx(i),vidx(j)) = kv(i,j)*E_MOD*Iz/Le^3;
            Ke(widx(i),widx(j)) = kw(i,j)*E_MOD*Iy/Le^3;
        end
    end

   
    Mbase = [156    22*Le   54    -13*Le;
             22*Le  4*Le^2 13*Le -3*Le^2;
             54     13*Le   156   -22*Le;
            -13*Le -3*Le^2 -22*Le 4*Le^2];
    Me = zeros(8,8);
    for i = 1:4
        for j = 1:4
            Me(vidx(i),vidx(j)) = Mbase(i,j)*RHO_STL*A*Le/420;
            Me(widx(i),widx(j)) = Mbase(i,j)*RHO_STL*A*Le/420;
        end
    end

   
    Me_add_loc = zeros(8,8);
    for i = 1:4
        for j = 1:4
            Me_add_loc(vidx(i),vidx(j)) = Mbase(i,j)*RHO_FLUID*A_DISP*Le/420;
            Me_add_loc(widx(i),widx(j)) = Mbase(i,j)*RHO_FLUID*A_DISP*Le/420;
        end
    end

    
    idx8 = ((e-1)*4+1):((e-1)*4+8);
    for i = 1:8
        fi = dof2free(idx8(i));
        if fi<0, continue; end
        for j = 1:8
            fj = dof2free(idx8(j));
            if fj<0, continue; end
            Kf(fi+1,fj+1)        = Kf(fi+1,fj+1)        + Ke(i,j);
            Mf_struct(fi+1,fj+1) = Mf_struct(fi+1,fj+1) + Me(i,j);
            Mf_add   (fi+1,fj+1) = Mf_add   (fi+1,fj+1) + Me_add_loc(i,j);
        end
    end
end


Mf = Mf_struct + Mf_add;


zeta = 0.013;
[V,D] = eig(Kf, Mf);
w1    = sqrt(D(1,1))/2/pi;
w2  =sqrt(D(min(5,end),min(5,end)))/2/pi;
w3    = sqrt(D(min(3,end),min(3,end)))/2/pi;
a0    = 2*zeta*w1*w3/(w1+w3);
a1    = 2*zeta/(w1+w3);
Cf    = a0*Mf + a1*Kf;


F        = readmatrix('fluid_forces.txt'); % [t, fy(bin1..), fz(bin1..)]
t        = F(:,1);
Fy_bin   = F(:,2:1+BIN_COUNT);
Fz_bin   = F(:,2+BIN_COUNT:end);
nstep    = length(t);



K        = readmatrix('point_ke.txt');
kt       = K(:,1);
Kpsd     = K(:,2);


Q_hist = zeros(N_FREE, nstep);
for k = 1:nstep
    Q = zeros(N_FREE,1);
    for n = 1:N_ELE
        fy = Fy_bin(k,n) / BIN_SIZE;
        fz = Fz_bin(k,n) / BIN_SIZE;

        fe_w = fz * Le/2 * [1; Le/6; 1; -Le/6];
        fe_v = fy * Le/2 * [1; Le/6; 1; -Le/6];
        Qe   = zeros(8,1);
        for i = 1:4
            Qe(widx(i)) = fe_w(i);
            Qe(vidx(i)) = fe_v(i);
        end

        for j = 1:8
            gid = dof2free((n-1)*4 + j);
            if gid>=0
                Q(gid+1) = Q(gid+1) + Qe(j);
            end
        end
    end
    Q_hist(:,k) = Q;
end

Q1 = Q_hist(:,1);
uu_static = Kf \ Q1;
idv_mid_static = dof2free(MID_NODE*4+1);
idw_mid_static = dof2free(MID_NODE*4+2);
disp_v_mid_stat = uu_static(idv_mid_static+1);
disp_w_mid_stat = uu_static(idw_mid_static+1);
fprintf('【静态】中点 v=%.3e m, w=%.3e m\n', disp_v_mid_stat, disp_w_mid_stat);


dt = t(2)-t(1);
[uu, vv, aa] = NewmarkBeta1_MDOF(Mf, Cf, Kf, Q_hist, dt, nstep);

% 提取中点响应
idv_mid = dof2free(MID_NODE*4 + 1);
idw_mid = dof2free(MID_NODE*4 + 2);
assert(idv_mid>=0, '中点 v DOF 非自由！');
assert(idw_mid>=0, '中点 w DOF 非自由！');
v_mid = uu(idv_mid+1, :);
w_mid = uu(idw_mid+1, :);
figure
plot(t,Fy_bin(:,1))
idv_L = dof2free(L_NODE*4 + 1);
idw_L = dof2free(L_NODE*4 + 2);
assert(idv_L>=0, '中点 v DOF 非自由！');
assert(idw_L>=0, '中点 w DOF 非自由！');
v_L = uu(idv_L+1, :);
w_L = uu(idw_L+1, :);

f1 = w1/(2*pi);
figure;
subplot(2,1,1);
plot(t, w_mid); xlabel('Time [s]'); ylabel('w [m]');
title('中点 w 位移响应');
xl = xlim; yl = ylim;
text(xl(1)+0.05*(xl(2)-xl(1)), yl(1)+0.9*(yl(2)-yl(1)), ...
     sprintf('f_1=%.2f Hz',f1), 'FontSize',12,'FontWeight','bold');

subplot(2,1,2);
plot(t, v_mid); xlabel('Time [s]'); ylabel('v [m]');
title('中点 v 位移响应');


fs = 1/dt;


N = length(w_mid);


Yw = fft(w_mid);

P2_w = (abs(Yw)/N).^2;

P1_w = P2_w(1:floor(N/2)+1);
P1_w(2:end-1) = 2*P1_w(2:end-1);
P1_w(2:end-1)=P1_w(2:end-1)/(fs/N);

f_w = fs*(0:floor(N/2))/N;


Yv = fft(v_mid);
P2_v = (abs(Yv)/N).^2;
P1_v = P2_v(1:floor(N/2)+1);
P1_v(2:end-1) = 2*P1_v(2:end-1);
f_v = f_w;  


figure;
subplot(2,2,1);
loglog(f_w, P1_w);
xlabel('Frequency [Hz]');
ylabel('PSD [dB/Hz]');
title('Midpoint w 位移 PSD (FFT 计算)');
grid on;

subplot(2,2,2);
loglog(f_v, P1_v);
xlabel('Frequency [Hz]');
ylabel('PSD [dB/Hz]');
title('Midpoint v 位移 PSD (FFT 计算)');
grid on;

